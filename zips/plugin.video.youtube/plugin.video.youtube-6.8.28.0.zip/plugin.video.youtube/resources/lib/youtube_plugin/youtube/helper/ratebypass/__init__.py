# -*- coding: utf-8 -*-
"""

    Copyright (C) 2021 plugin.video.youtube

    SPDX-License-Identifier: GPL-2.0-only
    See LICENSES/GPL-2.0-only for more information.
"""

from ....youtube.helper.ratebypass import ratebypass

__all__ = ['ratebypass']
